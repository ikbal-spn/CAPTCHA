/* SC ZEUXSS 𝙂𝙖𝙣𝙯𝙯 🔥
BASE : HW MODS
RECODE : ZEUXSS 𝙜𝙖𝙣𝙯𝙯 🔥
WA JAPOST : 089620156570
WA REKBER : 089620156570
BUY SC 10K CHAT WA JASAPOST
*/

const fs = require('fs')
const chalk = require('chalk')

global.owner = "6289620156570"
global.namabot = "Zeuxss-𝙗𝙤𝙩𝙯"
global.botname = "Zeuxss-𝙗𝙤𝙩𝙯𝙯"
global.autoJoin = true
global.codeInvite = "FwtMxovJqW3Jj55x524hjT"
global.thumb = fs.readFileSync("./thumb.png")
global.sessionName = 'zhirasession' //Gausah Juga
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.packname = ""
global.author = "ZEUXSS STORE"

global.namastore = "ZEUXSS STORE"
global.nodana = "089620156570"
global.nogopay = "089620156570"
global.noovo = "089620156570"
global.qris = "Scan Di Atas Yaa"

global.youtubehamxzz = "https://www.youtube.com/@Zeuxssnesiar"
global.instagramzhamxz = "-"
global.tiktokzhir = "tiktok.com/@zeuxssstore0"
global.grupjbzhir = "https://whatsapp.com/channel/0029Val3pBhAO7RJbNktP61U"
const mess = {
   wait: "Tunggu Bang Lagi Saya Proses",
   success: "sukses✅ Bang",
   save: "DONE SV✅",
   on: "Sudah Aktif", 
   off: "Sudah Off",
   query: {
       text: "Teks Nya Mana Kak?",
       link: "Link Nya Mana Kak?",
   },
   error: {
       fitur: "Mohon Maaf Kak Fitur Eror Silahkan Chat Developer Bot Agar Bisa Segera Diperbaiki",
   },
   only: {
       group: "Fitur Khusus Didalam Grup!",
       private: "Fitur Khusus Private!",
       owner: "Fitur Khusus Owner!",
       admin: "Fitur Khusus Admin Grup!",
       badmin: "Bot Bukan Admin Grup!",
       premium: "Maaf Kamu Belum Jadi User Premium Untuk Menjadi User Premium Silahkan Beli Ke Owner Dengan Cara Ketik .owner",
   }
}

global.mess = mess
//=================================================//
//Gausah Juga
global.limitawal = {
    premium: "Infinity",
    free: 100
}
//=================================================//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})